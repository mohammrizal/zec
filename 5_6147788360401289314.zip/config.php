<?php


$cfduid = "d4ac37c2ff2fd1e3fa4d952737f4ce8031553042788";

$ci_session = "uf4p7ecrau2vimgmarffv7u9pv1mak6p";

?>
